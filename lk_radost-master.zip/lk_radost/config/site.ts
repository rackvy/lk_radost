export const siteConfig = {
    name: "Личный кабинет Радость",
    description: "Личный кабинет Радость, будь в курсе событий!",
    url: "https://taskify.vercel.app",
    ogImage: "https://taskify.vercel.app/og.png",
    links: {
        twitter: "https://twitter.com/vercel",
        github: "https://github.com/vercel/next.js",
    },
}